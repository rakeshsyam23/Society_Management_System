package com.project.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.exception.ResourceNotFoundException;
import com.project.model.Member;
import com.project.repository.memberrepository;
import com.project.service.memberservice;

@CrossOrigin(origins="http://localhost:3000")
@RestController
public class Controller {

	@Autowired
	memberrepository mrespo;
	
	@Autowired
	memberservice service;
	
	@PostMapping("/mlogin")
	public Object memberlogin(@ModelAttribute("number") long number,@ModelAttribute("password") String password) {
		Boolean b=service.verifyuserlogin(number, password);
		Map<String,Object> object = new HashMap<>();
		if(b) {
			Member member= mrespo.findByNumber(number);
			String type= member.getMtype();
			int id=member.getId();
			String name= member.getFname();
			object.put("success","true");
			object.put("type", type);
			object.put("id",id);
			object.put("name", name);
		}
		else
			object.put("success","fail");
		return object;
		
	}
	@PostMapping("/member")
	public Member addmember(@RequestBody Member member) {
		return mrespo.save(member);	
	}
	@GetMapping("/getAllMembers")
	public List<Member> getAll(){
		return mrespo.findAll();
	}
	@GetMapping("/getmemberBycommitie")
	public List<Member> getCommititemembers() {
		String mtype="commitie";
		List<Member> members= mrespo.findByMtype(mtype);
		return members;
		
	}
	@GetMapping("/getmemberBysociety")
	public List<Member> getSocietymembers() {
		String mtype="society";
		List<Member> members= mrespo.findByMtype(mtype);
		return members;
		
	}
	@PutMapping("/member/{id}")
	public ResponseEntity<Member> editdetatils(@PathVariable int id,@RequestBody Member member) {
		
		Member mem= mrespo.findById(id).
				orElseThrow(()-> new ResourceNotFoundException("The member is not listed with the id:"+id));
		
		mem.setFname(member.getFname());
		mem.setMname(member.getMname());
		mem.setLname(member.getLname());
		mem.setWingno(member.getWingno());
		mem.setFlatno(member.getFlatno());
		mem.setCount(member.getCount());
		mem.setPassword(member.getPassword());
		
		Member updatemember= mrespo.save(mem);
		return ResponseEntity.ok(updatemember);
	}
	@GetMapping("/member/{id}")
	public ResponseEntity<Member> getmember(@PathVariable int id){
		
		Member member=mrespo.findById(id).
				orElseThrow(()-> new ResourceNotFoundException("The member is not listed with the id:"+id));
		return ResponseEntity.ok(member);
		
	}
}
