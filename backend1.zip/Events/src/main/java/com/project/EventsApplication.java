package com.project;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

import com.project.model.Events;
import com.project.repository.eventrepository;


@SpringBootApplication
@EnableDiscoveryClient
public class EventsApplication implements CommandLineRunner {
	
	@Autowired
	eventrepository erespo;
	
	public static void main(String[] args) {
		SpringApplication.run(EventsApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
//		Events e1= new Events("Ramzan","Celebration Hall",10000,"22-04-2023","8:00 am","We wish our Muslim brothers and sisters."
//				+ "Hope Everyone participate in this.Let's make this event successfull",1,"Approved");
//		Events e2= new Events("Our Flat Aniverseary","Play Ground",15000,"29-04-2023","6:00 pm",
//				"After Ganesh Pooja.There will be extra cultural activites.Hope Everyone participate in this.Let's make this event successfull",2,"Approved");
//		
//		erespo.save(e1);
//		erespo.save(e2);
	}

}
