package com.project.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.repository.eventrepository;
import com.project.exception.ResourceNotFoundException;
import com.project.model.*;

@CrossOrigin(origins="http://localhost:3000")
@RestController
public class Controller {
	
	@Autowired
	eventrepository erespo;
	
	@GetMapping("/getAll")
	public List<Events> getAllEvents(){
		return erespo.findAll();
	}
	@PostMapping("/events")
	public Events addevent(@RequestBody Events event) {
		
		return erespo.save(event);
	}
	@PutMapping("/event/{id}")
	public Events changeevent(@PathVariable int id) {
		Events event=erespo.findById(id).
				orElseThrow(()-> new ResourceNotFoundException("The member is not listed with the id:"+id));
		
		event.setStatus("Approved");
		erespo.save(event);
		return event;
	}
	@PutMapping("/eventform/{id}")
	public Events formchangeevent(@PathVariable int id,@ModelAttribute("status") String status) {
		Events event=erespo.findById(id).
				orElseThrow(()-> new ResourceNotFoundException("The member is not listed with the id:"+id));
		event.setStatus(status);
		erespo.save(event);
		return event;
	}

	

}
