package com.project.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.project.model.*;
public interface memberrepository extends JpaRepository<Member,Integer>{
	
	Member findByNumber(double number);
	List<Member> findByMtype(String mtype);
	
	@Query("select u from Member u where u.fname = :fname and u.lname = :lname")
	Member findByName(@Param("fname") String fname,@Param("lname") String lname);

}
