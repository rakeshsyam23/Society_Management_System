package com.project;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.project.model.Account;
import com.project.model.Amount;
import com.project.model.OnlinePayment;
import com.project.repository.accountrepository;
import com.project.repository.amountrepository;
import com.project.repository.onlinepaymentrepository;

@SpringBootApplication
public class AccountsApplication implements CommandLineRunner{
	
	@Autowired
	accountrepository arespo;
	
	@Autowired
	onlinepaymentrepository orespo;
	
	@Autowired
	amountrepository amrespo;
	

	public static void main(String[] args) {
		SpringApplication.run(AccountsApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
//		Amount amo= new Amount(7654,432,250,123,0);
//		amrespo.save(amo);
//		OnlinePayment op= new OnlinePayment("1,4,2023","ABC Street","Vizag","India","530026");
//		Account a1= new Account("03-2023","Paid",1,amo,op);
//		
//		orespo.save(op);
//		List<Account> accounts= new ArrayList<Account>();
//		
//		accounts.add(a1);
//	
//		
//		arespo.saveAll(accounts);
		
	}

}
