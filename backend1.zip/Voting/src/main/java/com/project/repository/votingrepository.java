package com.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.project.model.*;

public interface votingrepository extends JpaRepository <Voting,Integer> {
	
	@Query("Select u from Voting u where u.evid =:evid and u.rid=:rid")
	Voting findByevid(@Param("evid") int evid,@Param("rid") int rid);
	
	@Query("Select count(result) from Voting u where u.result=:result")
	int CountByresult(@Param("result") int result);
	
	List<Voting> findByEvid(int evid);
	
	@Query("Select u from Voting u where u.result=0 and u.rid=0")
	List<Voting> findEvents();
}
