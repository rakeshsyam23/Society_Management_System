package com.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.model.Voting;
import com.project.repository.votingrepository;

@Service
public class voterservice {

	@Autowired
	votingrepository vrespo;
	
	public Boolean verifyvoter(int evid,int rid) {
		
		Voting voting=vrespo.findByevid(evid, rid);
		
		if(voting!=null) {
			return false;
		}
		else {
			return true;
		}	
	}
	

}
