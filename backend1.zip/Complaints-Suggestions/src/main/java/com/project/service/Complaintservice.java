package com.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.model.Member;
import com.project.repository.memberrepository;

@Service
public class Complaintservice {

	@Autowired
	memberrepository mrespo;
	
	
	

}
