import axios from "axios"

export const addElection = async (date, stime, etime, evname) => {
    let evid = parseInt(new Date().getTime().toString().slice(3))
    const res = await axios.post(`http://localhost:7000/votingevent`, null, {
        params: {
            evid: evid,
            evname: evname,
            date: date,
            stime: stime,
            etime: etime
        }
    }).then(response => response.data)
    return res
}

export const addParticpants = async (evid, rids) => {
    const res = await axios.post(`http://localhost:7000/addparticipants`, {
        evid: evid,
        rid: rids
    }).then(response => response.data)
    return res
}

export const votingEvents = async () => {
    const res = await axios.get(`http://localhost:7000/votingevents`).then(response => response.data)
    return res
}

export const getParticpants = async (id) => {
    const res = await axios.get(`http://localhost:7000/participant/${id}`).then(response => response.data)
    return res
}

export const addVote = async (rid, eid, vote) => {
    const res = await axios.post(`http://localhost:7000/vote/${rid}`, null, {
        params: {
            evid: eid,
            result: vote
        }
    }).then(response => response.data)
    return res
}

export const isVotedOrNot = async (eid, rid) => {
    const res = await axios.get(`http://localhost:7000/checkvote/${rid}?evid=${eid}`).then(response => response.data)
    return res.vote
}

export const getResults = async (id) => {
    const res = await axios.get(`http://localhost:7000/votingresult/${id}`)
    return res.data.votingResult
}

export function results(arr) {
    let frequency = {};  // an object to keep track of the frequency of each number
    let maxFrequency = 0;  // variable to keep track of the maximum frequency found so far

    // loop through the array and count the frequency of each number
    for (let i = 0; i < arr.length; i++) {
        let num = arr[i];
        frequency[num] = (frequency[num] || 0) + 1;  // increment the frequency count for this number

        // update the maximum frequency if we have found a new maximum
        if (frequency[num] > maxFrequency) {
            maxFrequency = frequency[num];
        }
    }

    let mostRepeatedNumbers = [];

    // loop through the frequency object and add any numbers with a frequency equal to the maximum to the result array
    for (let num in frequency) {
        if (frequency[num] === maxFrequency) {
            mostRepeatedNumbers.push(Number(num));
        }
    }
    if (mostRepeatedNumbers.length === 1) {
        return [mostRepeatedNumbers[0]];  // if there is only one most repeated number, return it
    } else {
        return mostRepeatedNumbers;  // if there are multiple most repeated numbers, return them all as an array
    }
}