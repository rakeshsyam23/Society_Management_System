import React, { useId, useRef } from "react";
import { Container, Form, Button } from "react-bootstrap";
import { createEvent } from "../../utils/event";
import { userIdState, userNumberState, userTypeState } from "../../atoms";
import { useRecoilState } from "recoil";

export default function EventScheduling() {
  const [userId, setUserId] = useRecoilState(userIdState);
  const [userType, _] = useRecoilState(userTypeState);
  const [userNumber, setUserNumber] = useRecoilState(userNumberState);

  const eventNameRef = useRef();
  const eventDateRef = useRef();
  const eventTimeRef = useRef();
  const eventPlaceRef = useRef();
  const eventDescriptionRef = useRef();
  const eventBudgetRef = useRef();

  const submit = async (e) => {
    e.preventDefault();
    let data = {
      name: eventNameRef.current.value,
      date: eventDateRef.current.value,
      time: eventTimeRef.current.value,
      place: eventPlaceRef.current.value,
      description: eventDescriptionRef.current.value,
      budget: eventBudgetRef.current.value,
      rid: userId,
      rnumber: userNumber,
    };

    const res = await createEvent(data, userType);
    console.log(res);
    if (res.eventid) {
      alert("Event Created");
      window.location.reload();
    } else {
      alert("Something went wrong");
      window.location.reload();
    }
  };

  return (
    <Container
      style={{
        maxWidth: "700px",
        backgroundColor: "white",
        margin: "20px auto",
        padding: "20px",
      }}
    >
      <h2>Event Scheduling</h2>
      <Form
        style={{
          border: "1px solid black",
          padding: "10px",
          borderRadius: "10px",
        }}
      >
        <Form.Group className="mb-3" controlId="formBasicEName">
          <Form.Label>Enter Event name*</Form.Label>
          <Form.Control
            type="text"
            ref={eventNameRef}
            placeholder="Enter Event Name"
            required
          />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicDate">
          <Form.Label>Date*</Form.Label>
          <Form.Control type="date" ref={eventDateRef} required />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicTime">
          <Form.Label>Time*</Form.Label>
          <Form.Control type="time" ref={eventTimeRef} required />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicPlace">
          <Form.Label>Place*</Form.Label>
          <Form.Control
            type="text"
            ref={eventPlaceRef}
            placeholder="Enter place"
            required
          />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicDescription">
          <Form.Label>Event Description*</Form.Label>
          <Form.Control
            as="textarea"
            rows={5}
            ref={eventDescriptionRef}
            placeholder="Complient Description"
            required
          />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicBudget">
          <Form.Label>Budget</Form.Label>
          <Form.Control
            type="number"
            ref={eventBudgetRef}
            placeholder="Budget"
          />
        </Form.Group>
        <Button variant="primary" type="submit" onClick={(e) => submit(e)}>
          Submit
        </Button>
      </Form>
    </Container>
  );
}
