import React from "react";
import { Card, Container } from "react-bootstrap";

export default function CommunityWiki() {
  return (
    <Container
      style={{
        backgroundColor: "white",
        padding: "20px",
        maxWidth: "500px",
        margin: "50px auto",
      }}
    >
      <Card style={{ maxWidth: "500px", margin: "auto" }}>
        <Card.Header>
          <h3>COMMMUNITY WIKI</h3>
        </Card.Header>
        <Card.Body>
          <h4>RULES AND REGULATIONS:</h4>
          <ul style={{ textAlign: "left" }}>
            <li>RULE 1:RIGHTS AND PRIVILEGES OF MEMBERS</li>
            <li>RULE 2:FUNCTION & POWERS OF COMMITTEE MEMBERS</li>
            <li>RULE 3:COMPOSITION THE COMMITTEE MEMBERS</li>
            <li>RULE 4:MANAGEMENT OF FUNDS & ACCOUNTS OPERATION</li>
            <li>RULE 5:VOTING</li>
            <li>RULE 6:NEWSLETTER/BULLETINS</li>
            <li>RULE 7:USAGE AND TIMINGS OF SOCIETY FACILITIES</li>
          </ul>
        </Card.Body>
      </Card>
    </Container>
  );
}