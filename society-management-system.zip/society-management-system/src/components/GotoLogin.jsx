import React from "react";
import { Button } from "react-bootstrap";
import { Link } from "react-router-dom";

export default function GotoLogin() {
  return (
    <div
      style={{
        backgroundColor: "white",
        padding: "20px",
        margin: "50px auto",
        maxWidth: "400px",
      }}
    >
      <h3>You're not logged in</h3>
      <p>Please login to view content.</p>
      <Button as={Link} to="/">
        Login
      </Button>
    </div>
  );
}
