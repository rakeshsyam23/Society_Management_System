import React, { useEffect, useState } from "react";
import { Container, Table } from "react-bootstrap";
import { getEvents } from "../../utils/event";

export default function BEvents() {
  const [allComplaints, setAllcomplaints] = useState();

  useEffect(() => {
    const fetchAllComplaints = async () => {
      const res = await getEvents();
      setAllcomplaints(res);
    };
    fetchAllComplaints();
    console.log(allComplaints);
  }, []);
  return (
    <Container
      style={{
        backgroundColor: "white",
        padding: "20px",
        margin: "50px auto",
      }}
    >
      <br />
      <h2>All Events</h2>
      <br />

      <Table striped bordered hover>
        <thead>
          <tr>
            <th>EId</th>
            <th>Date & Time</th>
            <th>Name</th>
            <th>Description</th>
            <th>Place</th>
            <th>Budget</th>
          </tr>
        </thead>
        <tbody>
          {allComplaints?.map((e) => {
            if (e.status === "Approved")
              return (
                <tr>
                  <td>{e.eventid}</td>
                  <td>
                    {e.date} at {e.time}
                  </td>
                  <td>{e.eventname}</td>
                  <td style={{ maxWidth: "200px" }}>{e.description}</td>
                  <td>{e.place}</td>
                  <td>{e.budget}</td>
                </tr>
              );
          })}
        </tbody>
      </Table>
    </Container>
  );
}
