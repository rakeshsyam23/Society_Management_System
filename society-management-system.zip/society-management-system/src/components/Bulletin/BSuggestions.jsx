import React, { useEffect, useState } from "react";
import { Container, Table } from "react-bootstrap";
import { getAllsuggestions, members } from "../../utils/complaints";

export default function BSuggestions() {
  const [allSuggestions, setAllSuggestions] = useState();
  const [membersList, setMembersList] = useState();

  useEffect(() => {
    const fetchAllSuggestions = async () => {
      const res = await getAllsuggestions();
      setAllSuggestions(res);
    };
    fetchAllSuggestions();
    const getMembers = async () => {
      const res = await members();
      setMembersList(res);
    };
    getMembers();
  }, []);

  const getName = (id) => {
    const name = membersList?.filter((member) => member.id === id);
    if (name) {
      return name[0]?.fname;
    }
  };

  return (
    <Container
      style={{
        backgroundColor: "white",
        padding: "20px",
        margin: "50px auto",
      }}
    >
      <br />
      <h2>All suggestions</h2>
      <br />
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>CId</th>
            <th>Date</th>
            <th>Name</th>
            <th>Description</th>
            <th>Solution</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {allSuggestions?.map((e) => {
            return (
              <tr>
                <td>{e.id}</td>
                <td>{e.date}</td>
                <td>{getName(e.rid)}</td>
                <td>{e.description}</td>
                <td>{e.solution}</td>
                <td>{e.status}</td>
              </tr>
            );
          })}
        </tbody>
      </Table>
    </Container>
  );
}
