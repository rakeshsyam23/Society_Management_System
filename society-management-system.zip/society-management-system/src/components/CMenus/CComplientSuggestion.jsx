import React, { useEffect, useRef, useState } from "react";
import { useRecoilState } from "recoil";
import { userIdState, userTypeState } from "../../atoms";
import PageNotFound from "../pageNotFound";
import {
  members,
  getComplaints,
  getAllComplaints,
  getAllsuggestions,
  getSuggestions,
} from "../../utils/complaints";
import { Button, Container, Form, Modal, Table } from "react-bootstrap";
import axios from "axios";

export default function CComplientSuggestion() {
  const [userType, setUserType] = useRecoilState(userTypeState);
  const [userId, setUserId] = useRecoilState(userIdState);

  const [type, setType] = useState("Complaints");

  const [pendingComplaints, setPendingComplaints] = useState();
  const [pendingSuggestions, setPendingSuggestions] = useState();
  const [membersList, setMembersList] = useState();
  useEffect(() => {
    const getPendingComplaints = async () => {
      const res = await getComplaints();
      setPendingComplaints(res);
    };
    getPendingComplaints();
    const getPendingSuggestions = async () => {
      const res = await getSuggestions();
      setPendingSuggestions(res);
    };
    getPendingSuggestions();
    const getMembers = async () => {
      const res = await members();
      setMembersList(res);
    };
    getMembers();
  }, []);

  const getName = (id) => {
    const name = membersList?.filter((member) => member.id === id);
    if (name) {
      return name[0]?.fname;
    }
  };

  const accept = async (id) => {
    const res = await axios
      .put(`http://localhost:4000/complaint/${id}`, null, {
        params: {
          id: id,
          respondent_id: userId,
          status: "Accepted",
        },
      })
      .then((response) => response.data);
    if (res.id) {
      alert("Accepted Successfully");
      window.location.reload();
    }
  };

  const reject = async (id) => {
    const res = await axios
      .put(`http://localhost:4000/complaint/${id}`, null, {
        params: {
          id: id,
          respondent_id: userId,
          status: "Declined",
        },
      })
      .then((response) => response.data);
    if (res.id) {
      alert("Rejected Successfully");
      window.location.reload();
    }
  };

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const sugSolution = useRef();
  const [sugId, setsugId] = useState();

  const complete = async (id) => {
    handleShow();
    setsugId(id);
  };
  const completed = async () => {
    const res = await axios
      .put(`http://localhost:4000/suggestion/${sugId}`, null, {
        params: {
          solution: sugSolution.current.value,
        },
      })
      .then((response) => response.data);
    if (res.id) {
      alert("Completed Successfully");
      window.location.reload();
    } else {
      alert("Something went wrong");
      window.location.reload();
    }
  };

  if (userType !== "committee") {
    return <PageNotFound />;
  }

  return (
    <Container
      style={{
        backgroundColor: "white",
        padding: "20px",
        margin: "50px auto",
      }}
    >
      <h2>Complaints and Suggestions</h2>
      <Button onClick={() => setType("Complaints")}>Complaints</Button>{" "}
      <Button onClick={() => setType("Suggestions")}>Suggestions</Button>
      <br />
      <hr />
      <br />
      <h3>Pending {type}</h3>
      {type == "Complaints" && (
        <>
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>CId</th>
                <th>Date</th>
                <th>Complaintent Name</th>
                <th>Resident Name</th>
                <th>Description</th>
                <th>Solution</th>
                <th>Accept</th>
                <th>Reject</th>
              </tr>
            </thead>
            <tbody>
              {pendingComplaints?.map((e) => {
                return (
                  <tr>
                    <td>{e.id}</td>
                    <td>{e.date}</td>
                    <td>{getName(e.complaintant_id)}</td>
                    <td>{e.rid ? getName(e.rid) : "-"}</td>
                    <td>{e.description}</td>
                    <td>{e.solution}</td>
                    <td>
                      <Button variant="success" onClick={() => accept(e.id)}>
                        Accept
                      </Button>
                    </td>
                    <td>
                      <Button variant="danger" onClick={() => reject(e.id)}>
                        Reject
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
          <AllComplaints getName={getName} />
        </>
      )}
      {type == "Suggestions" && (
        <>
          <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
              <Modal.Title>Solution</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Form.Control
                as="textarea"
                rows={5}
                placeholder="Suggestion Solution"
                ref={sugSolution}
                required
              />
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={handleClose}>
                Close
              </Button>
              <Button variant="success" onClick={completed}>
                Completed
              </Button>
            </Modal.Footer>
          </Modal>
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>SId</th>
                <th>Date</th>
                <th>Name</th>
                <th>Description</th>
                <th>Solution</th>
                <th>Status</th>
                <th>Complete</th>
              </tr>
            </thead>
            <tbody>
              {pendingSuggestions?.map((e) => {
                return (
                  <tr>
                    <td>{e.id}</td>
                    <td>{e.date}</td>
                    <td>{getName(e.rid)}</td>
                    <td>{e.description}</td>
                    <td>{e.solution}</td>
                    <td>{e.status}</td>
                    <th>
                      <Button variant="success" onClick={() => complete(e.id)}>
                        Complete
                      </Button>
                    </th>
                  </tr>
                );
              })}
            </tbody>
          </Table>
          <AllSuggestions getName={getName} />
        </>
      )}
    </Container>
  );
}

const AllComplaints = ({ getName }) => {
  const [allComplaints, setAllcomplaints] = useState();
  const [allAcceptedComplaints, setAllAcceptedcomplaints] = useState();
  const [allRejectedComplaints, setAllRejectedcomplaints] = useState();
  const [allCompletedComplaints, setAllCompletedcomplaints] = useState();
  const [status, setStatus] = useState("All");
  const [statusList, setStatusList] = useState();

  const stautsLabels = ["All", "Accepted", "Declined", "Completed"];

  useEffect(() => {
    const fetchAllComplaints = async () => {
      const res = await getAllComplaints();
      setStatusList(res);
      setAllcomplaints(res);
      setAllAcceptedcomplaints(res.filter((e) => e.status == "Accepted"));
      setAllRejectedcomplaints(res.filter((e) => e.status == "Declined"));
      setAllCompletedcomplaints(res.filter((e) => e.status == "Completed"));
    };
    fetchAllComplaints();
    console.log(allComplaints);
  }, []);

  useEffect(() => {
    if (status == "All") setStatusList(allComplaints);
    if (status == "Accepted") setStatusList(allAcceptedComplaints);
    if (status == "Declined") setStatusList(allRejectedComplaints);
    if (status == "Completed") setStatusList(allCompletedComplaints);
  }, [status]);

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const cmpSolution = useRef();
  const [cmpId, setcmpId] = useState();

  const complete = async (id) => {
    handleShow();
    setcmpId(id);
  };

  const completed = async () => {
    if (cmpSolution.current.value) {
      const res = await axios
        .put(`http://localhost:4000/finalcomplaint/${cmpId}`, null, {
          params: {
            id: cmpId,
            solution: cmpSolution.current.value,
          },
        })
        .then((response) => response.data);
      if (res.id) {
        alert("Completed Successfully");
        window.location.reload();
      }
    }
  };

  return (
    <>
      <br />
      {stautsLabels?.map((e) => {
        return (
          <Button onClick={() => setStatus(e)} style={{ marginRight: "10px" }}>
            {e}
          </Button>
        );
      })}
      <br />
      <br />
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Solution</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Control
            as="textarea"
            rows={5}
            placeholder="Complient Solution"
            ref={cmpSolution}
            required
          />
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="success" onClick={completed}>
            Completed
          </Button>
        </Modal.Footer>
      </Modal>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>CId</th>
            <th>Date</th>
            <th>Complaintent Name</th>
            <th>Resident Name</th>
            {status == "Accepted" && <th>Respondent Name</th>}
            <th>Description</th>
            <th>Solution</th>
            <th>Status</th>
            {status == "Accepted" && <th>Complete</th>}
          </tr>
        </thead>
        <tbody>
          {statusList?.map((e) => {
            return (
              <tr>
                <td>{e.id}</td>
                <td>{e.date}</td>
                <td>{getName(e.complaintant_id)}</td>
                <td>{e.rid ? getName(e.rid) : "-"}</td>
                {status == "Accepted" && <td>{getName(e.respondent_id)}</td>}
                <td>{e.description}</td>
                <td>{e.solution}</td>
                <td>{e.status}</td>
                {status == "Accepted" && (
                  <th>
                    <Button variant="success" onClick={() => complete(e.id)}>
                      Complete
                    </Button>
                  </th>
                )}
              </tr>
            );
          })}
        </tbody>
      </Table>
    </>
  );
};

const AllSuggestions = ({ getName }) => {
  const [allSuggestions, setAllSuggestions] = useState();
  const [allCompletedSuggestions, setAllCompletedSuggestions] = useState();
  const [status, setStatus] = useState("All");
  const [statusList, setStatusList] = useState();

  const stautsLabels = ["All", "Completed"];

  useEffect(() => {
    const fetchAllSuggestions = async () => {
      const res = await getAllsuggestions();
      setStatusList(res);
      setAllSuggestions(res);
      setAllCompletedSuggestions(res.filter((e) => e.status == "Completed"));
    };
    fetchAllSuggestions();
    console.log(allSuggestions);
  }, []);

  useEffect(() => {
    if (status == "All") setStatusList(allSuggestions);
    if (status == "Completed") setStatusList(allCompletedSuggestions);
  }, [status]);

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const cmpSolution = useRef();
  const [cmpId, setcmpId] = useState();

  const complete = async (id) => {
    handleShow();
    setcmpId(id);
  };

  const completed = async () => {
    if (cmpSolution.current.value) {
      const res = await axios
        .put(`http://localhost:4000/finalcomplaint/${cmpId}`, null, {
          params: {
            id: cmpId,
            solution: cmpSolution.current.value,
          },
        })
        .then((response) => response.data);
      if (res.id) {
        alert("Completed Successfully");
        window.location.reload();
      }
    }
  };

  return (
    <>
      <br />
      {stautsLabels?.map((e) => {
        return (
          <Button onClick={() => setStatus(e)} style={{ marginRight: "10px" }}>
            {e}
          </Button>
        );
      })}
      <br />
      <br />
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Solution</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Control
            as="textarea"
            rows={5}
            placeholder="Complient Solution"
            ref={cmpSolution}
            required
          />
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="success" onClick={completed}>
            Completed
          </Button>
        </Modal.Footer>
      </Modal>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>SId</th>
            <th>Date</th>
            <th>Name</th>
            <th>Description</th>
            <th>Solution</th>
            <th>Status</th>
            {status == "Accepted" && <th>Complete</th>}
          </tr>
        </thead>
        <tbody>
          {statusList?.map((e) => {
            return (
              <tr>
                <td>{e.id}</td>
                <td>{e.date}</td>
                <td>{getName(e.rid)}</td>
                <td>{e.description}</td>
                <td>{e.solution}</td>
                <td>{e.status}</td>
                {status == "Accepted" && (
                  <th>
                    <Button variant="success" onClick={() => complete(e.id)}>
                      Complete
                    </Button>
                  </th>
                )}
              </tr>
            );
          })}
        </tbody>
      </Table>
    </>
  );
};
