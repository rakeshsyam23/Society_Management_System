import React, { useEffect, useRef, useState } from "react";
import { useRecoilState } from "recoil";
import { userTypeState } from "../../atoms";
import PageNotFound from "../pageNotFound";
import { members as getMembers } from "../../utils/complaints";
import { Button, Container, Form } from "react-bootstrap";
import { addElection, addParticpants } from "../../utils/election";

export default function CVoting() {
  const [userType, setUserType] = useRecoilState(userTypeState);
  const [members, setMembers] = useState();
  const [particpants, setParticpants] = useState([]);

  const enameRef = useRef();
  const dateRef = useRef();
  const stimeRef = useRef();
  const etimeRef = useRef();

  useEffect(() => {
    const getAllMembers = async () => {
      const res = await getMembers();
      setMembers(res);
    };
    getAllMembers();
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    let evname = enameRef.current.value;
    let date = dateRef.current.value;
    let stime = stimeRef.current.value;
    let etime = etimeRef.current.value;
    let rids = particpants;
    if (date && stime && etime) {
      if (particpants.length > 1) {
        const res = await addElection(date, stime, etime, evname);
        if (res.evid) {
          const resp = await addParticpants(res.evid, rids);
          if (resp.id) {
            alert("Election created successfully");
            window.location.reload();
          } else {
            alert("Something went wrong");
            window.location.reload();
          }
        } else {
          alert("Something went wrong");
          window.location.reload();
        }
      } else {
        alert("Choose atleast 2 particpants");
      }
    } else {
      alert("Fill date and timings");
    }
  };

  if (userType !== "committee") {
    return <PageNotFound />;
  }
  return (
    <Container
      style={{
        backgroundColor: "white",
        padding: "20px",
        margin: "50px auto",
      }}
    >
      <h2>Create New Election</h2>
      <Form
        style={{
          border: "1px solid black",
          padding: "10px",
          borderRadius: "10px",
          maxWidth: "500px",
          margin: "auto",
        }}
      >
        <Form.Group className="mb-3" controlId="formBasicName">
          <Form.Label>Enter Election name</Form.Label>
          <Form.Control type="text" ref={enameRef} required />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicDate">
          <Form.Label>Choose Start Date</Form.Label>
          <Form.Control type="date" ref={dateRef} required />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicStime">
          <Form.Label>Choose Start time</Form.Label>
          <Form.Control type="time" ref={stimeRef} required />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicEtime">
          <Form.Label>Choose End time</Form.Label>
          <Form.Control type="time" ref={etimeRef} required />
        </Form.Group>
        <Form.Label>Choose Atleast 2 particpants</Form.Label>
        {members?.map((member) => {
          return (
            <Form.Check
              style={{ maxWidth: "200px", margin: "auto" }}
              type="checkbox"
              id={"checkbox"}
              onClick={() => {
                if (particpants.includes(member.id)) {
                  setParticpants((particpants) => {
                    return particpants.filter((value) => value !== member.id);
                  });
                } else setParticpants([...particpants, member.id]);
              }}
              label={`${member.fname} ${member.lname}`}
            />
          );
        })}
        <Button
          variant="primary"
          type="submit"
          style={{ marginTop: "20px" }}
          onClick={(e) => submit(e)}
        >
          Submit
        </Button>
      </Form>
    </Container>
  );
}
