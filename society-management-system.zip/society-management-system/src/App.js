import './App.css';
import React, { useEffect } from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { useRecoilState } from "recoil";

import { isUserLoggedInState, userIdState, userNameState, userTypeState } from "./atoms";
import { auth } from './utils/auth';

import Home from './components/Home';
import Login from './components/Login';
import Nav from './components/Nav';
import pageNotFound from './components/pageNotFound';

import Accounting from './components/Menus/Accounting';
import Bulletin from './components/Menus/Bulletin';
import CommunityWiki from './components/Menus/CommunityWiki';
import ComplientSuggestion from './components/Menus/ComplientSuggestion';
import EventScheduling from './components/Menus/EventScheduling';
import Voting from './components/Menus/Voting';
import Logout from './components/Logout';
import GotoLogin from './components/GotoLogin';
import CAccounting from './components/CMenus/CAccounting';
import CComplientSuggestion from './components/CMenus/CComplientSuggestion';
import CVoting from './components/CMenus/CVoting';
import BVoting from './components/Bulletin/BVoting';
import BEvents from './components/Bulletin/BEvents';
import BComplaints from './components/Bulletin/BComplaints';
import BSuggestions from './components/Bulletin/BSuggestions';
import CRegisterMember from './components/CMenus/CRegisterMember';
import CUpdateMember from './components/CMenus/CUpdateMember';
import CEvent from './components/CMenus/CEvent';
import PasswordUpdate from './components/Menus/PasswordUpdate';

function App() {
  const [isUserLoggedIn, setIsUserLoggedIn] =
    useRecoilState(isUserLoggedInState);
  const [userId, setUserId] = useRecoilState(userIdState);
  const [userName, setUserName] = useRecoilState(userNameState);
  const [userType, setUserType] = useRecoilState(userTypeState);


  useEffect(() => {
    const checkUser = async () => {
      let user
      const userToken = window.localStorage.getItem('userToken')
      if (userToken) {
        user = atob(userToken).split(' ')
        let res = await auth(user[0], user[1])
        if (res.success == 'true') {
          setIsUserLoggedIn(true)
          setUserId(user[2])
          setUserName(user[3])
          setUserType(user[4])
        }
      }
    }
    checkUser()
  }, [])

  return (
    <div className="App home-bg">
      <Nav />
      {
        isUserLoggedIn &&
        <Logout />
      }
      <BrowserRouter>
        <Routes>
          <Route exact path='/' Component={isUserLoggedIn ? Home : Login} />
          <Route exact path='/bulletin' Component={isUserLoggedIn ? Bulletin : GotoLogin} />
          <Route exact path='/communitywiki' Component={isUserLoggedIn ? CommunityWiki : GotoLogin} />
          <Route exact path='/voting' Component={isUserLoggedIn ? Voting : GotoLogin} />
          <Route exact path='/accounting' Component={isUserLoggedIn ? Accounting : GotoLogin} />
          <Route exact path='/complaint-suggestion' Component={isUserLoggedIn ? ComplientSuggestion : GotoLogin} />
          <Route exact path='/events-scheduling' Component={isUserLoggedIn ? EventScheduling : GotoLogin} />
          <Route exact path='/password-update' Component={isUserLoggedIn ? PasswordUpdate : GotoLogin} />
          {/* commitite */}
          <Route exact path='/voting-contoller' Component={isUserLoggedIn ? CVoting : GotoLogin} />
          <Route exact path='/accounting-contoller' Component={isUserLoggedIn ? CAccounting : GotoLogin} />
          <Route exact path='/complaint-suggestion-contoller' Component={isUserLoggedIn ? CComplientSuggestion : GotoLogin} />
          <Route exact path='/events-contoller' Component={isUserLoggedIn ? CEvent : GotoLogin} />
          <Route exact path='/register-member' Component={isUserLoggedIn ? CRegisterMember : GotoLogin} />
          <Route exact path='/update-member' Component={isUserLoggedIn ? CUpdateMember : GotoLogin} />
          {/* bulletins */}
          <Route exact path='/bulletin/results-of-voting' Component={isUserLoggedIn ? BVoting : GotoLogin} />
          <Route exact path='/bulletin/details-of-events' Component={isUserLoggedIn ? BEvents : GotoLogin} />
          <Route exact path='/bulletin/details-of-complaints' Component={isUserLoggedIn ? BComplaints : GotoLogin} />
          <Route exact path='/bulletin/details-of-suggestions' Component={isUserLoggedIn ? BSuggestions : GotoLogin} />
          <Route exact path='*' Component={pageNotFound} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
